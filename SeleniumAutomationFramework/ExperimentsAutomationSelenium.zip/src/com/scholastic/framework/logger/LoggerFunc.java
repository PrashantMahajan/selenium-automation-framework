package com.scholastic.framework.logger;

public abstract class LoggerFunc {

	abstract public void startFunction ();
	
}
