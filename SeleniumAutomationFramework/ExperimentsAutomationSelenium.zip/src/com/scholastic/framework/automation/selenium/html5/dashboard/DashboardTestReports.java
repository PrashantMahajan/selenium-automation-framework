package com.scholastic.framework.automation.selenium.html5.dashboard;

import com.scholastic.framework.automation.selenium.html5.AutomationTest;

public class DashboardTestReports extends AutomationTest {

	@Override
	public void testStart() {
		
	}

}
