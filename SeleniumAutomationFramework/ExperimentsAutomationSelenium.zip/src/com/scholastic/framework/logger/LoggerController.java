package com.scholastic.framework.logger;

import com.scholastic.framework.Controller;

public class LoggerController extends Controller {

	public static LoggerController getInstance () {
		return new LoggerController();
	}
	
	public void capruteScreen () {
		LoggerFuncCaptureScreen v_fn;
		v_fn = new LoggerFuncCaptureScreen();
		v_fn.startFunction();
	}
	
}
